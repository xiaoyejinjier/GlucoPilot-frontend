# 控糖健康管理系统（AI控糖助手）· 后台管理前端

PC 端管理后台（Vue3 + TypeScript + Vite + Pinia + Element Plus + ECharts）。
与微信小程序端（`../控糖健康管理系统`）视觉风格对齐（主色绿 `#07c160` / 背景 `#f2f4f3` / 三套主题 green·teal·simple）。

> 纯前端演示工程：**无后端依赖**，数据由 `src/mock` 提供内存数据并写入 localStorage 持久化。
> 接入真实后端时，只需按 `src/types` 中的接口形状替换 `src/mock/index.ts` 的实现，页面无需改动。

## 快速开始

```bash
npm install        # 或 pnpm install
npm run dev        # 开发服务器 http://127.0.0.1:5180
npm run build      # 生产构建（输出 dist/）
npm run preview    # 预览构建产物
```

演示账号（登录页可一键填入）：

| 账号 | 密码 | 角色 | 可见范围 |
|---|---|---|---|
| admin | admin123 | 管理员 | 全部菜单（含用户/健康档案、系统管理） |
| editor01 / editor02 | editor123 | 运营编辑 | 看板、内容、营养库、反馈、导出（不含用户健康明细与系统管理） |

> 首次使用某一数据后修改会写入浏览器 localStorage（key `kt_admin_db_v1`）；如需还原演示数据，清除该 key 或浏览器存储后刷新。

## 功能清单（已敲定）

### 数据看板 `/dashboard`
注册/活跃、今日血糖与饮食记录、待处理反馈指标卡；近 14 天趋势（折线+柱）、用户达标分布（饼）、资讯频道分布（柱）、九时段记录热度（条形）；运营提示。

### 内容管理（`/content/*`，运营+管理员）
- 资讯管理：频道（企业动态/行业快讯/设备新知/控糖科普）、图文/视频、草稿→发布/下架（无审核环节）、阅读/点赞/收藏统计、删除
- 轮播图管理：首页 4 张循环轮播的图片/标题/跳转（文章或外链）/排序/启停
- 媒体素材：按用途分类管理（资讯配图/轮播/饮食照片/头像），模拟上传

### 营养库管理 `/nutrition/foods`（运营+管理员）
食物分类维护；食物条目 CRUD（名称/分类/每100g 碳水/热量/GI/图片/启停）；CSV 批量导入与导出（小程序端 food-db 的数据源）。

### 用户与服务（用户管理/健康档案仅管理员）
- 反馈管理 `/feedback`：类型/状态筛选，状态流转 待处理→处理中→已完成，回复回写，处理记录入日志
- 导出任务 `/exports`：用户申请的数据导出任务跟踪、模拟完成与下载
- 用户管理 `/users`（仅管理员）：用户禁用/解禁
- 健康档案 `/user-service/archives`（仅管理员，独立页面）：左侧选用户 → 右侧查看档案详情（基础资料 / 近 7 日血糖趋势图 / 分时段均值 / 饮食汇总 / AI 小结），可导出档案；**每次查阅自动记录操作日志**

### 系统管理（仅管理员）
- 角色权限 `/system/roles`：角色权限矩阵 + 后台账号管理（新增/编辑/停用）
- 系统参数 `/system/config`：血糖分级阈值（lowDanger/warnStart/dangerStart）、小程序端默认主题/字号/提醒开关、免责声明/用户协议/关于/公告文案
- 操作日志 `/system/logs`：写操作审计（登录/发布/删除/反馈/禁用/配置等）

### 二期占位
- 消息推送 `/message/push`、AI 服务配置 `/ai/config`（占位页，规划内容已写明）

## 目录结构

```
admin-web
├─ index.html / vite.config.ts / tsconfig.json
└─ src
   ├─ main.ts · App.vue
   ├─ styles/tokens.css          # 设计令牌 + Element Plus 主题覆盖（对齐小程序）
   ├─ types/index.ts             # 实体类型（对接后端 DTO 参考）
   ├─ mock/index.ts              # Mock 数据与“接口”（唯一需要替换的后端层）
   ├─ stores                     # auth（登录/角色）· app（主题/折叠）
   ├─ router/index.ts            # 路由 + 角色守卫 + 菜单定义
   ├─ layouts/AdminLayout.vue    # 侧边菜单/顶栏(面包屑·主题·用户)
   ├─ components                 # StatCard · EChart
   └─ views
      ├─ LoginView.vue
      ├─ dashboard · content · nutrition · users · system · placeholder · error
```

## 视觉对齐说明
- 设计令牌来自小程序 `app.wxss` 与 `utils/display.js`：主色 `#07c160`、背景 `#f2f4f3`、圆角、PingFang SC/微软雅黑。
- 顶栏提供 健康绿/清新青/极简灰 三主题切换（等同小程序"界面展示"设置）。
- 血糖状态颜色沿用小程序：达标绿 `#07c160`、偏高橙 `#fa9d3b`、需关注红 `#fa5151`。

## 待接入真实后端的点
1. `src/mock/index.ts` 中每个方法对应用户端 API.md 管理端扩展（建议 `/admin/v1/**`），替换为 axios 请求即可。
2. 登录改为后端校验 JWT 后，替换 `stores/auth.ts` 与路由守卫中的本地判断。
3. 健康档案、操作日志等敏感接口需在服务端按角色/权限鉴权。
