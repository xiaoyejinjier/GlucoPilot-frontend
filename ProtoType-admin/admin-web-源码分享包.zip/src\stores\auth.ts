import { defineStore } from 'pinia'
import { api } from '@/mock'
import type { Role } from '@/types'

interface AccountSession {
  id: number
  username: string
  nickname: string
  role: Role
}

const AUTH_KEY = 'kt_admin_auth'

function readSession(): AccountSession | null {
  try {
    const raw = localStorage.getItem(AUTH_KEY)
    return raw ? (JSON.parse(raw) as AccountSession) : null
  } catch {
    return null
  }
}

export const useAuthStore = defineStore('auth', {
  state: () => ({
    account: readSession() as AccountSession | null
  }),
  getters: {
    isLoggedIn: (s) => !!s.account,
    role: (s) => (s.account ? s.account.role : 'editor')
  },
  actions: {
    async login(username: string, password: string) {
      const acc = await api.login(username, password)
      this.account = { id: acc.id, username: acc.username, nickname: acc.nickname, role: acc.role }
      localStorage.setItem(AUTH_KEY, JSON.stringify(this.account))
      return this.account
    },
    logout() {
      this.account = null
      localStorage.removeItem(AUTH_KEY)
    }
  }
})
